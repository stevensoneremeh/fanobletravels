/*--------------Date Picker------------------*/
$( "#datepicker" ).datepicker({
    dateFormat: "dd-yy"
    , duration: "fast"
  });
